﻿namespace FurnitureManufacturer.Interfaces
{
    public interface ITable
    {
        decimal Length { get; }

        decimal Width { get; }

        decimal Area { get; }
    }
}
