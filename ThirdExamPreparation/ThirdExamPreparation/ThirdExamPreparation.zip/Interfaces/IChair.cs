﻿namespace FurnitureManufacturer.Interfaces
{
    public interface IChair
    {
        int NumberOfLegs { get; }
    }
}
