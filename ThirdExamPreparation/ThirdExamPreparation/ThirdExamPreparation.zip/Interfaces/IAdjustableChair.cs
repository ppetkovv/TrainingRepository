﻿namespace FurnitureManufacturer.Interfaces
{
    public interface IAdjustableChair
    {
        void SetHeight(decimal height);
    }
}
