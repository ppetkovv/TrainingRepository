﻿namespace FurnitureManufacturer.Models
{
    public class DoNotDeleteMe
    {
        // It is very important class!
    }
}
